library platform.interface.browser_detect;

final Browser browser = new Browser();

class Browser {
    bool isIe;
    bool isSafari;
}